print("Hello Zee")
print("Python has 3 numeric types: int float and complex ")
