print("Python has 3 numeric types: int float and complex ")



myval = 1
print(myval)
print(type(myval))
print(str(myval) + " is of the data type " + str(type(myval)) + "\n")

myval = 3.14
print(myval)
print(type(myval))
print(str(myval) + " is of datatype " + str(type(myval)))

myval = 5j
print(myval)
print(type(myval))
print(str(myval) + " is of datatype " + str(type(myval)))


myval = True
print(myval)
print(type(myval))
print(str(myval) + " is of datatype " + str(type(myval)))

myval = False
print(myval)
print(type(myval))
print(str(myval) + " is of datatype " + str(type(myval)))




